clc;clear all;close all;
% format long;
% x = 0.1896; 
%  y = 0.784;
% fun3(x,y)
% y=1.744053665381151;
% lb=-100;ub=100;
% c=0.0001;
% while abs(ub-lb)>c
%     xmid=(lb+ub)/2;
%     ymid=fun3(xmid,);
%     if ymid<y
%         lb=xmid;
%     else
%         ub=xmid;
%     end
% end
% X=(lb+ub)/2;

